import axios from 'axios';

const BASE_URL = 'http://localhost:8000';

export const runPythonCode = async (code: string, token: string) => {
  const response = await axios.post(
    `${BASE_URL}/user/admin/api/content`,
    { code },
    {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    }
  );
  return response.data;
};
