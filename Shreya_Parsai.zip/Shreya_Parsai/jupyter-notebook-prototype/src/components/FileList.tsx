import React, { useState } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';

const fileSchema = z.object({
  fileName: z.string().min(1, "File name can't be empty"),
});

type FileForm = z.infer<typeof fileSchema>;

const FileList: React.FC = () => {
  const [files, setFiles] = useState<string[]>([]);
  const { register, handleSubmit, reset, formState: { errors } } = useForm<FileForm>({
    resolver: zodResolver(fileSchema),
  });

  const addFile: SubmitHandler<FileForm> = ({ fileName }) => {
    setFiles([...files, fileName]);
    reset();
  };

  return (
    <div>
      <h3>Files</h3>
      <ul>
        {files.map((file, index) => (
          <li key={index}>{file}</li>
        ))}
      </ul>
      <form onSubmit={handleSubmit(addFile)}>
        <input {...register('fileName')} placeholder="New File Name" />
        <button type="submit">Add File</button>
        {errors.fileName && <p>{errors.fileName.message}</p>}
      </form>
    </div>
  );
};

export default FileList;
