import React, { useState } from 'react';
import axios from 'axios';

const CodeCell: React.FC = () => {
  const [code, setCode] = useState('');
  const [output, setOutput] = useState('');

  const runCode = async () => {
    try {
      const response = await axios.post(
        'http://localhost:8000/user/admin/api/content',
        { code },
        {
          headers: {
            Authorization: `Bearer YOUR_TOKEN_HERE`,
            'Content-Type': 'application/json',
          },
        }
      );
      setOutput(response.data.output);
    } catch (error) {
      setOutput('Error executing code.');
    }
  };

  return (
    <div>
      <textarea
        value={code}
        onChange={(e) => setCode(e.target.value)}
        placeholder="Write Python code here"
      />
      <button onClick={runCode}>Run</button>
      {output && <pre>{output}</pre>}
    </div>
  );
};

export default CodeCell;
