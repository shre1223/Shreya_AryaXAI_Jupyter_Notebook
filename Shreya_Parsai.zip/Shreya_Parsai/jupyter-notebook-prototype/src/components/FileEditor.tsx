import React, { useState } from 'react';
import CodeCell from './CodeCell';

const FileEditor: React.FC = () => {
  const [codeCells, setCodeCells] = useState<number[]>([1]);

  const addCodeCell = () => {
    setCodeCells([...codeCells, codeCells.length + 1]);
  };

  return (
    <div>
      <h3>File Editor</h3>
      {codeCells.map((cell) => (
        <CodeCell key={cell} />
      ))}
      <button onClick={addCodeCell}>Add Code Cell</button>
    </div>
  );
};

export default FileEditor;
