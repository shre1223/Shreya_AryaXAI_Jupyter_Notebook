import React from 'react';
import FileList from '../components/FileList';
import FileEditor from '../components/FileEditor';

const Notebook: React.FC = () => {
  return (
    <div style={{ display: 'flex' }}>
      <aside style={{ width: '30%' }}>
        <FileList />
      </aside>
      <main style={{ width: '70%' }}>
        <FileEditor />
      </main>
    </div>
  );
};

export default Notebook;
